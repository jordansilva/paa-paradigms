//
//  main.cpp
//  Assassins Greed
//
//  Created by Jordan Silva on 10/11/15.
//  Copyright © 2015 Jordan Silva. All rights reserved.
//

#include <iostream>
#include "src/helper/Settings.hpp"
#include "src/algorithms/Dynamic.hpp"

#define DEFAULT_FOLDER "./"
#define FILE_FOES "data/foes.txt"
#define FILE_LEVELS "data/levels.txt"

int main(int argc, const char * argv[]) {
    string fFoes = string(DEFAULT_FOLDER) + string(FILE_FOES);
    string fLevels = string(DEFAULT_FOLDER) + string(FILE_LEVELS);
    Settings settings(fFoes, fLevels);
    
    //Dynamic
    cout << "Dynamic" << endl;
    Dynamic pdAlgorithm(settings.getFoes(), settings.getLevels());

    return 0;
}
