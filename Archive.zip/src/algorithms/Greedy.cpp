//
//  Greedy.cpp
//  Assassins Greed
//
//  Created by Jordan Silva on 10/11/15.
//  Copyright © 2015 Jordan Silva. All rights reserved.
//

#include "Greedy.hpp"

#include <algorithm>
#include <ctime>

Greedy::Greedy(vector<int> foes, vector<int> levels) {
    execute(&foes, &levels);
}

Greedy::~Greedy() {
    
}

vector<int> Greedy::execute(vector<int>* foes, int level) {
    vector<int> result;
    if (level == 0)
        return result;
    
        for (int i = (int)foes->size()-1; i >= 0; i--) {
            
            if (foes->at(i) <= level)
            {
                level -= foes->at(i);
                result.push_back(foes->at(i));
                
                vector<int> temp = execute(foes, level);
                
                for (int t : temp)
                {
                    level -= t;
                    result.push_back(t);
                }
            }
    }
    
    return result;
}

void Greedy::execute(vector<int>* foes, vector<int>* levels) {
    for (int i = 0; i < levels->size(); i++) {
        clock_t begin = clock();
        
        Level level(levels->at(i));
        cout << "Level: " << level.getDifficulty() << endl;

        //Getting level
        vector<int> result = execute(foes, level.getDifficulty());
        level.addFoes(result);

        //Printing
        clock_t end = clock();
        double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
        level.print();
        cout << " Time elapsed: " << elapsed_secs << endl;
    }
}

